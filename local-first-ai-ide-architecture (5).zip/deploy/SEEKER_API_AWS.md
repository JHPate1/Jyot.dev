# Seeker API on AWS — Full Guide

This guide deploys a **branded Seeker API gateway** that:

1. Accepts Seeker API keys (`sk_seeker_…`)
2. Checks them against a DynamoDB key database
3. Enforces a **daily message limit** (default **50/day**, adjustable per key)
4. Maps public model names → real NVIDIA models + secret NVIDIA keys
5. Streams OpenAI-compatible SSE so the Seeker Code app needs **zero code changes** beyond the base URL

The browser never talks to `integrate.api.nvidia.com`. It only sees:

```
https://your-seeker-api…/v1/chat/completions
Authorization: Bearer sk_seeker_…
model: seeker-pro-1.2 | seeker-perplex | seeker-code-flash
```

---

## Architecture

```
┌──────────────── Seeker Code (browser) ────────────────┐
│  Authorization: Bearer sk_seeker_xxx                  │
│  model: "seeker-pro-1.2"                              │
└───────────────────────┬───────────────────────────────┘
                        │ HTTPS
                        ▼
┌────────────── AWS Lambda Function URL ────────────────┐
│  seeker-api  (Node 20, RESPONSE_STREAM)                │
│                                                       │
│  1. Validate key  ──► DynamoDB seeker-api-keys        │
│  2. Check quota   ──► DynamoDB seeker-api-usage       │
│  3. Map model     ──► internal MODEL_MAP              │
│  4. Proxy stream  ──► integrate.api.nvidia.com/v1     │
│  5. Rewrite SSE model id back to seeker-*             │
└───────────────────────────────────────────────────────┘
```

### Public model → internal mapping

| Public (browser)     | Real NVIDIA model                         | Secret env var          |
|----------------------|-------------------------------------------|-------------------------|
| `seeker-pro-1.2`     | `nvidia/nemotron-3-super-120b-a12b`       | `NVIDIA_KEY_PRO`        |
| `seeker-perplex`     | `deepseek-ai/deepseek-v4-flash-0731`      | `NVIDIA_KEY_PERPLEX`    |
| `seeker-code-flash`  | `meta/llama-3.3-70b-instruct`             | `NVIDIA_KEY_FLASH`      |

---

## One-command deploy

```bash
chmod +x scripts/deploy-seeker-api.sh

# Optional overrides
export AWS_REGION=us-east-1
export DEFAULT_DAILY_LIMIT=50
export NVIDIA_KEY_PRO=nvapi-…
export NVIDIA_KEY_PERPLEX=nvapi-…
export NVIDIA_KEY_FLASH=nvapi-…
export ADMIN_SECRET=$(openssl rand -hex 24)   # save this
export CORS_ORIGIN=https://main.dxxxxx.amplifyapp.com   # or *

./scripts/deploy-seeker-api.sh
```

The script prints:

- **Base URL** — paste into `VITE_SEEKER_API_URL`
- **Admin secret** — used to mint keys
- **Demo API key** — paste into Seeker Code → Settings

---

## Manual deploy (console walkthrough)

### 1. DynamoDB tables

**Table A — `seeker-api-keys`**

| Attribute | Type | Key |
|-----------|------|-----|
| `keyHash` | String | Partition key |

Billing: **On-demand**.

Item shape:

```json
{
  "keyHash": "<sha256 of sk_seeker_…>",
  "keyPrefix": "sk_seeker_ab12…",
  "label": "alice",
  "dailyLimit": 50,
  "active": true,
  "createdAt": "2026-04-01T12:00:00Z",
  "updatedAt": "2026-04-01T12:00:00Z",
  "ownerEmail": "alice@example.com"
}
```

> The raw key is **never stored**. Only its SHA-256 hash.

**Table B — `seeker-api-usage`**

| Attribute | Type | Key |
|-----------|------|-----|
| `keyHash` | String | Partition key |
| `day`     | String | Sort key (`YYYY-MM-DD` UTC) |

Item shape:

```json
{ "keyHash": "…", "day": "2026-04-08", "count": 12, "updatedAt": "…" }
```

Optional: enable **TTL** on attribute `ttl` so old days auto-expire.

### 2. IAM role

Trust: `lambda.amazonaws.com`  
Managed policy: `AWSLambdaBasicExecutionRole`  
Inline policy:

```json
{
  "Effect": "Allow",
  "Action": ["dynamodb:GetItem","dynamodb:PutItem","dynamodb:UpdateItem","dynamodb:Scan","dynamodb:Query"],
  "Resource": [
    "arn:aws:dynamodb:REGION:ACCOUNT:table/seeker-api-keys",
    "arn:aws:dynamodb:REGION:ACCOUNT:table/seeker-api-usage"
  ]
}
```

### 3. Lambda function

| Setting | Value |
|---------|-------|
| Runtime | Node.js 20.x |
| Handler | `index.handler` |
| Memory | 512 MB |
| Timeout | 300 s |
| Package | `api/index.mjs` + `node_modules` (run `npm install --omit=dev` in `api/`) |

**Environment variables**

| Key | Example |
|-----|---------|
| `KEYS_TABLE` | `seeker-api-keys` |
| `USAGE_TABLE` | `seeker-api-usage` |
| `NVIDIA_KEY_PRO` | `nvapi-…` |
| `NVIDIA_KEY_PERPLEX` | `nvapi-…` |
| `NVIDIA_KEY_FLASH` | `nvapi-…` |
| `NVIDIA_BASE_URL` | `https://integrate.api.nvidia.com/v1` |
| `ADMIN_SECRET` | long random string |
| `DEFAULT_DAILY_LIMIT` | `50` |
| `CORS_ORIGIN` | your Amplify domain or `*` |

### 4. Function URL (critical for streaming)

Lambda → Configuration → Function URL:

- **Auth type:** NONE (the Seeker key is app-level auth)
- **Invoke mode:** **RESPONSE_STREAM** ← required for SSE
- **CORS:** allow your Amplify origin, headers `Authorization, Content-Type, X-Seeker-Admin`

Add resource-based permission:

```bash
aws lambda add-permission \
  --function-name seeker-api \
  --statement-id FunctionURLAllowPublicAccess \
  --action lambda:InvokeFunctionUrl \
  --principal "*" \
  --function-url-auth-type NONE
```

Your public base URL looks like:

```
https://xxxxxxxx.lambda-url.us-east-1.on.aws
```

App base URL = that + `/v1`:

```
https://xxxxxxxx.lambda-url.us-east-1.on.aws/v1
```

---

## API reference

### `GET /v1/models`
No auth. Lists Seeker-branded models only.

### `GET /v1/usage`
```
Authorization: Bearer sk_seeker_…
→ { "day":"2026-04-08", "used":12, "limit":50, "remaining":38 }
```

### `POST /v1/chat/completions`
OpenAI-compatible. Same body the IDE already sends.

```json
{
  "model": "seeker-pro-1.2",
  "messages": [{ "role": "user", "content": "hi" }],
  "stream": true,
  "temperature": 1,
  "top_p": 0.95,
  "max_tokens": 16384,
  "chat_template_kwargs": { "enable_thinking": true }
}
```

Headers on success:
- `X-Seeker-Remaining: 37`
- `X-Seeker-Model: seeker-pro-1.2`

Errors:
| Status | Meaning |
|--------|---------|
| 401 | Invalid key |
| 403 | Key disabled |
| 429 | Daily limit hit |
| 400 | Unknown model |
| 502 | NVIDIA upstream down |

### Admin (header `X-Seeker-Admin: $ADMIN_SECRET`)

```bash
# Create key (limit adjustable)
curl -X POST "$URL/v1/admin/keys" \
  -H "Content-Type: application/json" \
  -H "X-Seeker-Admin: $ADMIN_SECRET" \
  -d '{"label":"alice","dailyLimit":100,"ownerEmail":"a@x.com"}'
# → { "apiKey":"sk_seeker_…", "dailyLimit":100, … }

# List keys (hashes only — raw keys never stored)
curl "$URL/v1/admin/keys" -H "X-Seeker-Admin: $ADMIN_SECRET"

# Change limit or disable
curl -X PATCH "$URL/v1/admin/keys/<keyHash-or-raw-key>" \
  -H "Content-Type: application/json" \
  -H "X-Seeker-Admin: $ADMIN_SECRET" \
  -d '{"dailyLimit":200,"active":true}'
```

Or use the helper:

```bash
export SEEKER_API_URL=https://xxxx.lambda-url.us-east-1.on.aws
export SEEKER_ADMIN_SECRET=…
node api/seed-key.mjs --label alice --limit 100
```

---

## Wire Seeker Code (frontend)

### Local `.env`

```env
VITE_SEEKER_API_URL=https://xxxx.lambda-url.us-east-1.on.aws/v1
VITE_SEEKER_API_KEY=sk_seeker_…
```

### Amplify Console → Environment variables

| Key | Value |
|-----|-------|
| `VITE_SEEKER_API_URL` | `https://xxxx.lambda-url.us-east-1.on.aws/v1` |
| `VITE_SEEKER_API_KEY` | (optional default key shipped to users) |

Redeploy the frontend after setting these.

Users can always paste their own `sk_seeker_…` key in **Settings**.

---

## Adjusting the daily limit

| Scope | How |
|-------|-----|
| Default for new keys | `DEFAULT_DAILY_LIMIT` env on Lambda, then redeploy / update config |
| One user | `PATCH /v1/admin/keys/{id}` with `{"dailyLimit":200}` |
| Unlimited | set `dailyLimit` to a very large number, e.g. `999999` |
| Disable a user | `{"active":false}` |

Usage counters reset automatically at **00:00 UTC** (new `day` partition).

---

## Security checklist

- [x] Raw Seeker keys stored as SHA-256 only  
- [x] NVIDIA keys live only in Lambda env / Secrets Manager — never in the browser  
- [x] Public model names hide upstream vendor IDs  
- [x] SSE `model` field rewritten to Seeker ids on the way out  
- [x] Daily quota enforced before the upstream call  
- [x] Admin routes require `X-Seeker-Admin`  
- [ ] Restrict `CORS_ORIGIN` to your Amplify domain in production  
- [ ] Rotate `ADMIN_SECRET` and store it in Secrets Manager  
- [ ] Optional: put CloudFront + WAF in front of the Function URL  
- [ ] Optional: move NVIDIA keys from env → Secrets Manager + IAM read  

---

## Optional: Amplify rewrite (same-origin)

If you want the browser to call `/api/v1/*` on your Amplify domain (no CORS at all):

**Amplify → Rewrites and redirects → 200 rewrite**

```
Source: /api/<*>
Target: https://xxxx.lambda-url.us-east-1.on.aws/<*>
Type:   200 (Rewrite)
```

Then set:

```
VITE_SEEKER_API_URL=/api/v1
```

---

## Test end-to-end

```bash
URL=https://xxxx.lambda-url.us-east-1.on.aws
KEY=sk_seeker_…

# Models
curl "$URL/v1/models"

# Usage
curl "$URL/v1/usage" -H "Authorization: Bearer $KEY"

# Chat (non-stream)
curl "$URL/v1/chat/completions" \
  -H "Authorization: Bearer $KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"seeker-pro-1.2","messages":[{"role":"user","content":"Say hi in one sentence"}],"stream":false,"max_tokens":64}'

# Chat (stream)
curl -N "$URL/v1/chat/completions" \
  -H "Authorization: Bearer $KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"seeker-code-flash","messages":[{"role":"user","content":"ping"}],"stream":true,"max_tokens":32}'
```

---

## Cost notes

| Resource | Typical cost |
|----------|--------------|
| Lambda (512 MB, streaming) | pennies per 1k requests |
| DynamoDB on-demand | free tier covers most demos |
| Function URL | free |
| NVIDIA NIM tokens | your dominant cost |

---

## Files in this repo

```
api/
  index.mjs          # Lambda handler
  package.json       # @aws-sdk DynamoDB deps
  seed-key.mjs       # mint keys via admin API
scripts/
  deploy-seeker-api.sh
deploy/
  SEEKER_API_AWS.md  # this guide
```
