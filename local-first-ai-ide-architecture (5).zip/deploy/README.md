# Deploying Seeker Code

## Frontend (Amplify Hosting)

See `amplify.yml` and `scripts/setup-amplify.sh`.

Environment variables:

| Key | Value |
|-----|-------|
| `VITE_SEEKER_API_URL` | `https://xxxx.lambda-url.REGION.on.aws/v1` |
| `VITE_SEEKER_API_KEY` | optional default `sk_seeker_…` |

## Backend (Seeker API gateway)

**Full guide:** [`SEEKER_API_AWS.md`](./SEEKER_API_AWS.md)

```bash
./scripts/deploy-seeker-api.sh
```

Creates DynamoDB key + usage tables, a streaming Lambda, a public Function URL, and mints a demo Seeker key with a 50 messages/day limit (adjustable per key).
